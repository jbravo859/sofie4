A 40% Ortho keyboard made by Polarity Works

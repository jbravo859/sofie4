/*
 * Copyright (c) 2020 The ZMK Contributors
 *
 * SPDX-License-Identifier: MIT
 */

#define OUT_TOG 0
#define OUT_USB 1
#define OUT_BLE 2